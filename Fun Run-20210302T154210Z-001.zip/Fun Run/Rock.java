import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rock here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rock extends Actor
{
    /**
     * Act - do whatever the Rock wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Rock() 
    {
        
        
        {GreenfootImage roc = new GreenfootImage("rock.png");
            roc.scale(roc.getWidth()/5, roc.getHeight()/5);
            setImage(roc);
        }
    }    
    public void act(){
        
    }
}
